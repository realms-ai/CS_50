<?

    // require common code
    require_once("includes/common.php"); 

?>

<!DOCTYPE html>

<html>

  <head>
    <link href="css/styles.css" rel="stylesheet" type="text/css">
    <title>C$50 Finance: Home</title>
  </head>

  <body>

    <div id="top">
      <a href="index.php"><img alt="C$50 Finance" height="110" src="images/logo.gif" width="544"></a>
    </div>

    <div id="middle">
      <img alt="Under Construction" height="299" src="images/construction.gif" width="404">
    </div>

    <div id="bottom">
      <a href="logout.php">log out</a>
    </div>

  </body>

</html>
