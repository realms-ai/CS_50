
<!DOCTYPE html>

<html>

  <head>
    <title>dump</title>
  </head>

  <body>
    <pre><? print_r($variable) ?></pre>
  </body>

</html>
