<?
    /***************************************************************
     * register0.php
     *
     * Computer Science 50
     * David J. Malan
     *
     * Dumps contents of $_POST.
     ***************************************************************/

?>

<!DOCTYPE html>

<html>
  <head>
    <title>Frosh IMs</title>
  </head>
  <body>
    <pre>
      <? print_r($_POST); ?>
    </pre>
  </body>
</html>
